Ivi Foundation Inc. Ivi Event Server Server Readme File
        Version 1.1.1.0

============================================================================
Version History

1.1.0.10
	- Fixed some memory leaks
	- Substituted AtlWaitWithMessageLoop with our own WaitWithMessageLoop
1.1.0.11
	- Modified self-registration to remove event server configuration
		entries from the registry.
	- The type libraries are now unregistered in DLLUnregisterServer.
1.1.1.0
	- Updated build system and some of the version resource values for
		autogeneration from the build system for better consistancy.

============================================================================
Copyright � 2002, Ivi Foundation Inc.  All Rights Reserved.
